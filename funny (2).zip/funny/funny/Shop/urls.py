from django.urls import path
from Shop.views import main_page

urlpatterns = [
    path('', main_page)
]

from django.http import HttpResponse
from django.shortcuts import render
import requests
from bs4 import BeautifulSoup as Bs


def main_page(request):
    return HttpResponse('<h1 style="color: red">Main Page!!!</h1>')


def get_info(request):
    pass






